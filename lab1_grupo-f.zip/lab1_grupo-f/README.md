# mps-lab1

## Laboratorio 1: pruebas unitarias con jUnit 5

Partiendo de la implementación de ClubDeportivo, realizar las pruebas unitarias correspondientes para validar la lógica de la aplicación. Un clubdeportivo está compuesto por diferentes actividades, y estas a su vez tendrán personas matriculadas y un número de plazas disponible. El club de alto rendimiento es igual a un club normal, excepto que el número de plazas de los grupos está limitado, y los ingresos del club tienen un incremento extra proporcional a los matriculados.

## Autores

- Pablo Gámez Guerrero
- Álvaro Gallardo Rubio