package clubdeportivo;

public class ClubException extends Exception{
	public ClubException() {
		super();
	}
	public ClubException(String mensaje) {
		super(mensaje);
	}
}
